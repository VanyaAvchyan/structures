<?php if($errors->any()): ?>
    <div class="error_message alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo $error; ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php if(Session::has('error')): ?>
    <div class="error_message alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <p><?php echo Session::get('error'); ?></p>
    </div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
    <div class="error_message alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <p><?php echo Session::get('success'); ?></p>
    </div>
<?php endif; ?>
<?php if(Session::has('warning')): ?>
    <div class="error_message alert alert-warning alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <p><?php echo Session::get('warning'); ?></p>
    </div>
<?php endif; ?>
<?php if(Session::has('notice')): ?>
    <div class="error_message alert alert-info alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <p><?php echo Session::get('notice'); ?></p>
    </div>
<?php endif; ?>

<?php 
    if(session('message')) {
    
    $additionalClasses = isset($classes) ? $classes : '';
?>
<div class="alert alert-<?php echo session('type'); ?> <?php echo $additionalClasses; ?> alert-dismissible fade show"
     role="alert">
    <?php echo session('message'); ?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php } ?><?php /**PATH C:\xampp\htdocs\onlinesuportpro\resources\views/alerts/message.blade.php ENDPATH**/ ?>