<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <title><?php echo e(env('APP_NAME')); ?> | Confirm Email</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>
<body>
<style>
    @font-face {
        font-family: 'Poppins';
        src: url("<?php echo e(url('/')); ?>/themes/default/fonts/poppins/Poppins-Regular.ttf?v=1.1.0") format("truetype");
        font-weight: 300;
        font-style: normal;
    }

    #confirm_link:hover {
        background-color: #00488a;
    }

    a:hover {
        text-decoration: underline;
    }
</style>
<table cellpadding="0" cellspacing="0" align="center"
       style="border: 2px solid rgba(29, 30, 31, 1);border-radius: 10px; width: 762px; height: 440px;background-image: url(<?php echo e(url('/')); ?>/themes/default/img/maryland-email-bg.svg);background-repeat: no-repeat;background-position: right bottom;">
    <tbody>
    <tr>
        <td></td>
        <td>
            <table cellpadding="0" cellspacing="0" align="center" style="width:100%">
                <tbody>
                <tr>
                    <td align="center"
                        style="padding:23px 0 50px 0">
                        <a href="<?php echo e(url('/')); ?>"
                           style="color:#126320;font-size:12px;text-decoration:none;line-height:22px"
                           rel="noopener noreferrer" target="_blank"
                           data-saferedirecturl="">
                            <img alt="" height="48px" width="117px" src="<?php echo e(url('/')); ?>/img/undraw_posting_photo.svg">
                        </a>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
        <td></td>
    </tr>
    <tr>
        <td colspan="3" width="100%" align="center">
            <h1 style="font-size: 52px;color: #141516;height: 58px;line-height: 58px;margin-top: 0;margin-bottom: 10px;">
                Welcome!</h1>
        </td>
    </tr>
    <tr>
        <td colspan="3" width="100%" align="center">
            <strong style="font-family: 'Poppins', SansSerif;font-size: 19px;color: #000;letter-spacing: 0.02em;line-height: 24px;">Please
                confirm your email<br>address to get started</strong>
        </td>
    </tr>
    <tr>
        <td colspan="3" height="42" align="center" width="100%" style="text-align:center;padding-top:36px;">
            <table cellpadding="0" cellspacing="0" align="center" width="276" style="width:276px">
                <tbody>
                <tr>
                    <td id="confirm_link" width="100%" height="42" align="center" valign="middle"
                        style="width:100%;height:42px;text-align:center;background-color:#1573C8;border-radius: 2px;text-transform: uppercase;">
                        <a href="<?php echo e($confirm_link); ?>" style="text-decoration:none;color:#FFFFFF;cursor: pointer;"
                           rel="noopener noreferrer" target="_blank">
                            <span style="display: block;font-weight: bold;font-size: 13px;font-family: 'Poppins', SansSerif;letter-spacing: 0.1em;text-align: center;line-height: 42px;padding-left: 20px;padding-right: 20px;">Confirm Email Address</span>
                        </a>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    </tbody>
</table>
</body>
</html><?php /**PATH C:\xampp\htdocs\onlinesuportpro\resources\views/theme1/emails/register.blade.php ENDPATH**/ ?>