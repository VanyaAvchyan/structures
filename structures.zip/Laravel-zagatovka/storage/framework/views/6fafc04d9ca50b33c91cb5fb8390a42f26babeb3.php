
<?php $__env->startSection('css'); ?>
    <link href="/css/sb-admin-2.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-7">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Login</h1>
                            </div>
                            <?php echo $__env->make('alerts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo Form::open(['url' => '/auth/postLogin', 'method'=>'POST', 'class'=>'user']); ?>

                            <div class="form-group">
                                <?php echo Form::email('email', old('email'), ['class'=>'form-control form-control-user', 'placeholder'=>'Email']); ?>

                            </div>
                            <div class="form-group row">
                                <div class="col-sm-12 mb-3 mb-sm-0">
                                    <?php echo Form::password('password', ['class'=>'form-control form-control-user', 'placeholder'=>'Password']); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <div class="custom-control custom-checkbox small">
                                    
                                    <?php echo Form::checkbox('remember_me', true, old('remember_me'), ['class'=>'custom-control-input', 'id'=>'remember_me']); ?>

                                    <?php echo Form::label('remember_me', 'Remember Me', ['class'=>'custom-control-label']); ?>

                                    
                                </div>
                            </div>
                            <?php echo Form::button('Login',['class' => 'btn btn-primary btn-user btn-block', 'type'=>'submit']); ?>

                            <hr>
                            <?php echo Form::close(); ?>

                            <hr>
                            <div class="text-center">
                                <a class="small" href="<?php echo e(url('auth/register')); ?>">Create an Account!</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="<?php echo e(url('auth/forgot-password')); ?>">Forgot Password?</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('default_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlinesuportpro\resources\views/theme1/auth/login.blade.php ENDPATH**/ ?>