
<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand-lg navbar-white bg-white static-top">
        <div class="container">
            <a class="navbar-brand" href="/">
                <img src="/img/logo.png" alt="">
            </a>
        </div>
    </nav>
    <!-- Outer Row -->
    <div class="row justify-content-center">
        <div class="col-xl-10 col-lg-12 col-md-9">
            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                </div>
                                <?php echo $__env->make('alerts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo Form::open(['url' => '/admin/postLogin', 'method'=>'POST', 'class'=>'user']); ?>

                                    <div class="form-group">
                                        <?php echo Form::email('email', old('email'), ['class'=>'form-control form-control-user', 'placeholder'=>'Enter Email Address...']); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo Form::password('password', ['class'=>'form-control form-control-user', 'placeholder'=>'Password']); ?>

                                    </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox small">
                                            
                                            <?php echo Form::checkbox('remember_me', true, old('remember_me'), ['class'=>'custom-control-input', 'id'=>'remember_me']); ?>

                                            <?php echo Form::label('remember_me', 'Remember Me', ['class'=>'custom-control-label']); ?>

                                            
                                        </div>
                                    </div>
                                    <?php echo Form::button('Login',['class' => 'btn btn-primary btn-user btn-block', 'type'=>'submit']); ?>

                                    <hr>
                                    <?php echo Form::close(); ?>

                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme1.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlinesuportpro\resources\views/theme1/admin/login.blade.php ENDPATH**/ ?>