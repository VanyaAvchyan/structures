
<?php $__env->startSection('css'); ?>
    <link href="/css/sb-admin-2.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-7">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                            </div>
                            <?php echo $__env->make('alerts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo Form::open(['url' => '/auth/postRegister', 'method'=>'POST', 'class'=>'user']); ?>


                                <div class="form-group">
                                    <div class="custom-control custom-checkbox small">
                                        <?php echo Form::radio('program', 1, 1, ['class'=>'custom-control-input', 'id'=>'program1']); ?>

                                        <?php echo Form::label('program1', 'Free', ['class'=>'custom-control-label']); ?>

                                    </div>
                                    <div class="custom-control custom-checkbox small">
                                        <?php echo Form::radio('program', 0, 0, ['class'=>'custom-control-input', 'id'=>'program2']); ?>

                                        <?php echo Form::label('program2', '50$', ['class'=>'custom-control-label']); ?>

                                    </div>
                                    <div class="custom-control custom-checkbox small">
                                        <?php echo Form::radio('program', 0, null, ['class'=>'custom-control-input', 'id'=>'program3']); ?>

                                        <?php echo Form::label('program3', '75$', ['class'=>'custom-control-label']); ?>

                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <?php echo Form::text('first_name', old('first_name'), ['class'=>'form-control form-control-user', 'placeholder'=>'First Name']); ?>

                                    </div>
                                    <div class="col-sm-6">
                                        <?php echo Form::text('last_name', old('last_name'), ['class'=>'form-control form-control-user', 'placeholder'=>'Last Name']); ?>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <?php echo Form::email('email', old('email'), ['class'=>'form-control form-control-user', 'placeholder'=>'Email']); ?>

                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <?php echo Form::password('password', ['class'=>'form-control form-control-user', 'placeholder'=>'Password']); ?>

                                    </div>
                                    <div class="col-sm-6">
                                        <?php echo Form::password('password_confirmation', ['class'=>'form-control form-control-user', 'placeholder'=>'Repeat Password']); ?>

                                    </div>
                                </div>
                            <?php echo Form::button('Register Account',['class' => 'btn btn-primary btn-user btn-block', 'type'=>'submit']); ?>

                                <hr>
                            <?php echo Form::close(); ?>

                            <hr>
                            <div class="text-center">
                                <a class="small" href="<?php echo e(url('auth/forgot-password')); ?>">Forgot Password?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="<?php echo e(url('auth/login')); ?>">Already have an account? Login!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('default_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlinesuportpro\resources\views/theme1/auth/register.blade.php ENDPATH**/ ?>