#Autoloader Optimization
composer install --optimize-autoloader --no-dev
composer update

#Cached data clearing
php artisan cache:clear
php artisan view:clear

#Optimizing View Loading
php artisan view:cache

#Reoptimized Class
php artisan optimize

#Migrate
php artisan migrate