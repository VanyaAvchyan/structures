<?php

use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $roles = [
            [
                'id' => '1',
                'name' => 'admin',
            ],
            [
                'id' => '2',
                'name' => 'user',
            ]
        ];
        foreach ($roles as $role)
        {
            if(!\App\Models\Role::whereName($role['name'])->update($role))
                \App\Models\Role::create($role);
        }
    }
}
