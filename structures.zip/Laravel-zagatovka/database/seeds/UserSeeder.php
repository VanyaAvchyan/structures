<?php

use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = [
            [
                'first_name' => 'Admin',
                'last_name' => 'Admin',
                'email' => 'admin@admin.com',
                'password' => app('hash')->make('123456'),
                'role_id' => 1,
                'program_id' => null,
                'completed' => 0
            ],
        ];
        foreach ($users as $user)
        {
            if(!\App\Models\User::whereEmail($user['email'])->update($user))
                \App\Models\User::create($user);
        }
    }
}
