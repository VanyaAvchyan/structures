<?php

namespace App\Models;

class StaticPage extends BaseModel
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'description',
        'tax',
    ];
}
