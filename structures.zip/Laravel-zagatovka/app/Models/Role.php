<?php

namespace App\Models;

class Role extends BaseModel
{
    const
        ADMIN=1,
        USER=2;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [];
}
