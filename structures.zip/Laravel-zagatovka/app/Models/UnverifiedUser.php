<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UnverifiedUser extends Model
{
    /**
     * DB table name
     * @var string

    protected $table = 'unverified_users';*/
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'code',
        'type',
        'user_id'
    ];
}
