<?php
namespace App\Services;
use App\Models\UnverifiedUser;
use App\Models\User;

class UserService extends ACRUDService {
    protected $model, $unverifiedUser;

    /**
     * UserService constructor.
     * @param User $user
     * @param UnverifiedUser $unverifiedUser
     */
    public function __construct(User $user, UnverifiedUser $unverifiedUser)
    {
        $this->model = $user;
        $this->unverifiedUser = $unverifiedUser;
    }

    public function register($data){
        $data['password'] =  app('hash')->make($data['password']);
        $data['role_id'] =  2;
        $data['completed'] =  0;

        $user = $this->create($data);
        $code = $this->sendRegisterEmail($data['email']);
        $unverifiedUserData = [
            'user_id' => $user->id,
            'type' => 'email',
            'code' => $code
        ];
        $this->unverifiedUser->create($unverifiedUserData);
        return $user;
    }

    /**
     * Email verification by code
     * @param string $code
     */
    public function emailVerifyByCode($code){

        $unverifiedUser = $this->unverifiedUser->whereCode($code)->first();
        if(!$unverifiedUser)
            throw new \Exception('Incorrect link');
        $this->update(['id' => $unverifiedUser->user_id], ['completed'=>1]);
        $userId = $unverifiedUser->user_id;
        $unverifiedUser->delete();

        return $userId;
    }
    /**
     * Send verification email
     *
     * @param string $to User email
     * @return string
     * @throws \Exception
     */
    private function sendRegisterEmail($to)
    {
        if(!$to)
            throw new \Exception('Email not set.');
        $hash = uniqid();
        $link = url('auth/email-verify/'.$hash);
        \Mail::to($to)->send(new \App\Mail\Sendgrid([
            'subject' => 'Email verification.',
            'vars' => [
                'confirm_link' => $link
            ],
            'view' => 'theme1.emails.register',
        ]));
        return $hash;
    }
}