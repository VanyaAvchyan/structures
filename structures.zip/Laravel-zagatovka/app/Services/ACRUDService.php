<?php
namespace App\Services;
abstract class ACRUDService
{
    /**
     * Get model or model-list by conditions.
     *
     * @param array $data
     * @param bool $debug
     *
     * @return mixed
     */
    public function get( array $data = [], $debug = false )
    {
        if ( empty( $data['orders'] ) ) {
            $data['orders'] = [];
        }

        if ( empty( $data['conditions'] ) ) {
            $data['conditions'] = [];
        }

        if ( ! array_key_exists( 'all', $data ) ) {
            $data['all'] = true;
        }

        $model = $this->model->where( $data['conditions'] );

        foreach ( $data['orders'] as $field => $order ) {
            $model = $model->orderBy( $field, $order );
        }

        if(!empty($data['in'])){
            foreach ( $data['in'] as $field => $values ) {
                $model = $model->whereIn( $field, $values );
            }
        }
        if(!empty($data['paginate'])){
            $model = $model->paginate($data['paginate']);
        }
        if(!empty($data['simplePaginate'])){
            $model = $model->simplePaginate($data['simplePaginate']);
        }
        if(!empty($data['paginate']) || !empty($data['simplePaginate'])){
            return $model;
        }
        if(!empty($data['select'])){
            $model = $model->select($data['select']);
        }

        if(!empty($data['offset'])){
            $model = $model->skip($data['offset']);
        }
        if(!empty($data['limit'])){
            $model = $model->take($data['limit']);
        }

        if ( $debug ) {
            return $model->toSql();
        }

        if ( $data['all'] ) {
            return $model->get();
        }
        return $model->first();
    }

    /**
     * Delete model by conditions.
     * If $conditions param is empty then delete all model
     *
     * @param array $conditions
     *
     * @return boolean
     */
    public function delete( array $conditions )
    {
        return $this->model->where( $conditions )->delete();
    }

    /**
     * Update model by conditions
     *
     * @param array $conditions
     * @param array $data
     *
     * @return \App\Models\AModel
     */
    public function update( array $conditions, array $data )
    {
        return $this->model->where( $conditions )->update( $data );
    }

    /**
     * Create model
     *
     * @param array $data
     *
     * @return \App\Models\AModel
     */
    public function create( array $data )
    {
        return $this->model->create( $data );
    }
    /**
     * Get model's fillable fields
     *
     * @return array
     */
    public function getFillable()
    {
        return $this->model->getFillable();
    }
}