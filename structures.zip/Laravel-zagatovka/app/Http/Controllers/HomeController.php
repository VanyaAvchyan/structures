<?php

namespace App\Http\Controllers;

class HomeController extends Controller
{
    private $path='home/';
    public function index()
    {
        return $this->response($this->path.__function__);
    }
}
