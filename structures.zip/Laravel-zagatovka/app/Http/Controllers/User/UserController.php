<?php

namespace App\Http\Controllers\User;
use App\Http\Controllers\Controller;
use App\Http\Requests\AdminSigninRequest;
use App\Models\Role;
use App\Services\UserService;

class UserController extends Controller
{
    /**
     * Main dir path
     * @var string
     */
    private $path='user/';

    /**
     * Dashboard view
     * @return \Illuminate\Support\Facades\View
     */
    public function index(UserService $userService)
    {
        $users = $userService->get([
            'conditions' => [
                ['role_id', '!=', Role::ADMIN],
                ['role_id', Role::USER],
                ['id', '!=', auth()->user()->id],
            ]
        ]);
        return $this->response($this->path.__function__, ['users'=>$users]);
    }
}
