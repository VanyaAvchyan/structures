<?php

namespace App\Http\Controllers;

//use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
//use Illuminate\Foundation\Bus\DispatchesJobs;
//use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
//use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    private $view='theme1/';
    /**
     * Return view
     *
     * @param string $view Path to view
     * @param array $args Variables for view
     * @return \Illuminate\Support\Facades\View
     */
    public function response($path = '', array $args = [])
    {
        return view($this->view.$path, $args);
    }
}