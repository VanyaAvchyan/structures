<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Http\Requests\AdminSigninRequest;
use App\Models\Role;

class AdminController extends Controller
{
    private $path='admin/';

    /**
     * Dashboard view
     * @return \Illuminate\Support\Facades\View
     */
    public function index()
    {
        return $this->response($this->path.__function__);
    }

    /**
     * Login view
     * @return \Illuminate\Support\Facades\View
     */
    public function login()
    {
        return $this->response($this->path.__function__);
    }

    /**
     * Logout
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function logout()
    {
        auth()->logout();
        return redirect('admin/login');
    }

    /**
     * Make login
     * @param AdminSigninRequest $request
     * @return $this|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function postLogin(AdminSigninRequest $request)
    {
        $credentials = $request->only('email', 'password');
        $credentials['role_id'] = Role::ADMIN;
        if (auth()->attempt($credentials, request()->get('remember_me'))) {
            return redirect('/admin');
        }
        return redirect('admin/login')->with('error', 'Login or password is incorrect!');
    }
}
