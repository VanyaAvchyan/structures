<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserSigninRequest;
use App\Http\Requests\UserSignupRequest;
use App\Models\Role;
use App\Services\UserService;
use DB;

class AuthController extends Controller
{
    private $path='auth/';

    /**
     * Login view
     * @return \Illuminate\Support\Facades\View
     */
    public function login()
    {
        return $this->response($this->path . __FUNCTION__);
    }

    /**
     * Logout
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function logout()
    {
        auth()->logout();
        return redirect('auth/login');
    }

    /**
     * Registration view
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|\Illuminate\Support\Facades\View
     */
    public function register()
    {
        if(auth()->check() && auth()->user()->role_id == Role::USER)
            return redirect('users');
        return $this->response($this->path . __FUNCTION__);
    }

    /**
     * Registration view
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector|\Illuminate\Support\Facades\View
     */
    public function forgotPassword()
    {
        return $this->response($this->path . __FUNCTION__);
    }

    /**
     * Make login
     * @return $this|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function postLogin(UserSigninRequest $request)
    {
        $credentials = $request->only('email', 'password');
        if (auth()->attempt($credentials, request()->get('remember_me'))) {
            return redirect('/users');
        }
        return redirect('auth/login')->with('error', 'Login or password is incorrect!');
    }

    /**
     * Make registration
     * @param UserSignupRequest $request
     * @return $this
     */
    public function postRegister(UserSignupRequest $request, UserService $userService)
    {
        try {
            $data = $request->only($userService->getFillable());
            DB::beginTransaction();
            $user = $userService->register($data);
            DB::commit();
            return redirect('auth/register-success');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /**
     * Email verification
     * @param string $code
     */
    public function emailVerify(UserService $userService, $code){
        try {
            DB::beginTransaction();
            $userId = $userService->emailVerifyByCode($code);
            auth()->loginUsingId($userId);
            DB::commit();
            return redirect('users');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
    /**
     * Make registration
     * @param UserSignupRequest $request
     * @return $this
     */
    public function registerSuccess()
    {
        return $this->response($this->path . __FUNCTION__);
    }
}
