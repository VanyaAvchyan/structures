<?php

namespace App\Http\Middleware;
use Closure;
class PublicMiddleware extends BaseMiddleware
{
    public function handle($request, Closure $next)
    {
        return $next($request);
    }
}
