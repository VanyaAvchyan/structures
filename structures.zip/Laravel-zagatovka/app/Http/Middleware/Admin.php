<?php

namespace App\Http\Middleware;
use Closure;
use App\Models\Role;
class Admin extends BaseMiddleware
{
    public function handle($request, Closure $next)
    {
        if(!auth()->check())
            return redirect('admin/login');
        if(auth()->user()->role_id !== Role::ADMIN)
            abort(403);
        return $next($request);
    }
}
