<?php

namespace App\Http\Middleware;
use App\Models\Role;
use Closure;
class User extends BaseMiddleware
{
    public function handle($request, Closure $next)
    {

        if(!auth()->check())
            return redirect('auth/login');
        $user = auth()->user();
        if($user->role_id !== Role::USER)
            abort(403);
        if(!$user->completed)
            abort(403, 'Your account not completed');
        return $next($request);
    }
}
