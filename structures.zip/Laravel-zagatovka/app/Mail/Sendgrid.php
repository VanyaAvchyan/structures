<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class Sendgrid extends Mailable
{
    use Queueable, SerializesModels;

    public $data;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(array $data)
    {
        $this->data = $data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        if(empty($this->data['subject']))
            throw new \Exception('Email subject is not set.');
        if(empty($this->data['vars']))
            $this->data['vars'] = [];
        if(empty($this->data['view']))
            throw new \Exception('Email view is not set.');
        $from = empty($this->data['from']) ? env('MAIL_FROM_ADDRESS','no_reply@inmd.com') : $this->data['from'];
        $to = empty($this->data['to']) ? false : $this->data['to'];
        $cc = empty($this->data['cc']) ? false : $this->data['cc'];
        $bcc = empty($this->data['bcc']) ? false : $this->data['bcc'];
        $subject = $this->data['subject'];
        $name = env('MAIL_FROM_NAME', 'Maryland');

        if(!empty($this->data['headers']))
        {
            // Adding a category or custom field
            $headerData = [
                'category' => $this->data['headers']['category'],
                'unique_args' => $this->data['headers']['unique_args'],// 'unique_args' => ['variable_1' => 'abc']
            ];
            $header = $this->asString($headerData);
            $this->withSwiftMessage(function ($message) use ($header) {
                $message->getHeaders()
                    ->addTextHeader('X-SMTPAPI', $header);
            });
        }
        $email = $this->view($this->data['view'])
            ->from($from, $name)
            ->subject($subject);
        if($to)
            $email->to($to);
        if($cc)
            $email->cc($cc, $name);
        if($bcc)
            $email->bcc($bcc, $name);
        if(!empty($this->data['replyTo']))
            $email->replyTo($this->data['replyTo'], $name);

        return $email->with($this->data['vars']);
    }
}
