<?php
use Illuminate\Support\Facades\Route;
Route::group([
    'middleware' => ['Public'],
], function() {
    Route::get('/', 'HomeController@index');
    /**Auth routes*/
    Route::get('admin/login', 'Admin\AdminController@login');
    Route::get('admin/logout', 'Admin\AdminController@logout');
    Route::post('admin/postLogin', 'Admin\AdminController@postLogin');

    Route::get('auth/login', 'AuthController@login');
    Route::get('auth/logout', 'AuthController@logout');
    Route::get('auth/register', 'AuthController@register');
    Route::get('auth/email-verify/{code}', 'AuthController@emailVerify');
    Route::get('auth/register-success', 'AuthController@registerSuccess');
    Route::get('auth/forgot-password', 'AuthController@forgotPassword');
    Route::post('auth/postLogin', 'AuthController@postLogin');
    Route::post('auth/postRegister', 'AuthController@postRegister');
    Route::post('auth/postForgotPassword', 'AuthController@postForgotPassword');

    /**User routes*/
    Route::group([
        'middleware' => ['User'],
        'namespace' => 'User',
        'prefix' => 'users',
    ], function() {
        Route::get('/', 'UserController@index');
    });

    /**Admin routes*/
    Route::group([
        'middleware' => ['Admin'],
        'namespace' => 'Admin',
        'prefix' => 'admin',
    ], function() {
        Route::get('/', 'AdminController@index');
    });
});