@extends('default_layout')
@section('title')
    Home page
@endsection
@section('content')

    <!-- Page Content -->
    <div class="container">
        <h1 class="mt-4">Logo Nav by Start Bootstrap</h1>
        <p>The logo in the navbar is now a default Bootstrap feature in Bootstrap 4! Make sure to set the width and height of the logo within the HTML or with CSS. For best results, use an SVG image as your logo.</p>
    </div>

    <div class="container">
        <h3>Basic Homepage Example</h3>
    </div>

@endsection