@extends('default_layout')
@section('css')
    <link href="/css/sb-admin-2.min.css" rel="stylesheet">
@endsection
@section('content')
    <div class="container">
        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-7">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                            </div>
                            @include('alerts.message')
                            {!!Form::open(['url' => '/auth/postRegister', 'method'=>'POST', 'class'=>'user'])!!}

                                <div class="form-group">
                                    <div class="custom-control custom-checkbox small">
                                        {!! Form::radio('program', 1, 1, ['class'=>'custom-control-input', 'id'=>'program1']) !!}
                                        {!! Form::label('program1', 'Free', ['class'=>'custom-control-label']) !!}
                                    </div>
                                    <div class="custom-control custom-checkbox small">
                                        {!! Form::radio('program', 0, 0, ['class'=>'custom-control-input', 'id'=>'program2']) !!}
                                        {!! Form::label('program2', '50$', ['class'=>'custom-control-label']) !!}
                                    </div>
                                    <div class="custom-control custom-checkbox small">
                                        {!! Form::radio('program', 0, null, ['class'=>'custom-control-input', 'id'=>'program3']) !!}
                                        {!! Form::label('program3', '75$', ['class'=>'custom-control-label']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        {!! Form::text('first_name', old('first_name'), ['class'=>'form-control form-control-user', 'placeholder'=>'First Name']) !!}
                                    </div>
                                    <div class="col-sm-6">
                                        {!! Form::text('last_name', old('last_name'), ['class'=>'form-control form-control-user', 'placeholder'=>'Last Name']) !!}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {!! Form::email('email', old('email'), ['class'=>'form-control form-control-user', 'placeholder'=>'Email']) !!}
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        {!! Form::password('password', ['class'=>'form-control form-control-user', 'placeholder'=>'Password']) !!}
                                    </div>
                                    <div class="col-sm-6">
                                        {!! Form::password('password_confirmation', ['class'=>'form-control form-control-user', 'placeholder'=>'Repeat Password']) !!}
                                    </div>
                                </div>
                            {!! Form::button('Register Account',['class' => 'btn btn-primary btn-user btn-block', 'type'=>'submit']) !!}
                                <hr>
                            {!! Form::close() !!}
                            <hr>
                            <div class="text-center">
                                <a class="small" href="{{url('auth/forgot-password')}}">Forgot Password?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="{{url('auth/login')}}">Already have an account? Login!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


@endsection
@section('js')

@endsection