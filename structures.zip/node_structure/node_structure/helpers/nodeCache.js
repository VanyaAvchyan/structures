const NodeCache = require("node-cache-promise");

const cache = new NodeCache();

module.exports = cache;